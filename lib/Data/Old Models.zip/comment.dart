import 'post.dart';
import 'user.dart';

class Comment {
  int id;
  String content;
  User user;
  Post post;
  DateTime dateTime;
}
